#!/usr/bin/env python
from __future__ import print_function
from __future__ import division
"""
`nested_dict` provides dictionaries with multiple levels of nested-ness:
"""
__version__ = '1.5.1'
from .implementation import nested_dict
